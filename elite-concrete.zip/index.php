<?php
include_once("includes/header.php");
include("$page.php");
include_once("includes/footer.php");
include_once("includes/copyright.php");
?>