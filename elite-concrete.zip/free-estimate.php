<div class="content">
    <div class="container">
        <div class="content-block">
            <div class="row">
                <div class="col-md-12 ">
                    <h2>Free Quotation</h2>
                    <div class="sectiontitleunderline"></div>
                    <div class="free-estimate-form">
                        <form class="form-horizontal" role="form" action="./get-quote-send" method="post" enctype="multipart/form-data">
                            <div class="form-group">
                                <div class="col-md-12 mb-4">
                                    <p class="freeblock"><strong>Your Basic Information</strong></p>
                                </div>
                            </div>
                            <div class="row form-col mb-3">
                                <div class="col-md-3">                      
                                <!-- Honeypot Field (Spam Prevention) -->
                                    <div style="display:none;">
                                      <input type="text" name="honeypot" id="honeypot" tabindex="-1" autocomplete="off" />
                                    </div>
                                    <i class="fa fa-user"></i><label>First Name* :</label>
                                    <input type="text" name="firstName" id="firstName" class="form-control freeestimatestyle" placeholder="Enter Your First Name" required>
                                </div>
                                <div class="col-md-3">
                                    <i class="fa fa-user"></i>
                                    <label>Last Name :</label>                                    
                                    <input type="text" name="lastName" class="form-control freeestimatestyle" placeholder="Enter Your Last Name">
                                </div>
                                <div class="col-md-3">
                                    <i class="fa fa-phone"></i>
                                    <label>Phone Number* :</label>
                                    <input type="tel" name="phone" class="form-control freeestimatestyle" placeholder="Enter Your Phone Number" required>
                                </div>
                                <div class="col-md-3">
                                    <i class="fa fa-phone"></i>
                                    <label>Alternate Phone :</label>
                                    <input type="tel" name="cell" class="form-control freeestimatestyle" placeholder="Enter Your Alternate Phone">
                                </div>
                            </div>
                              <div class="row form-col mb-3">  
                                <div class="col-md-6">
                                    <i class="fa fa-paper-plane"></i>
                                    <label>Email Address* :</label>
                                    <input type="email" name="email" class="form-control freeestimatestyle" placeholder="Enter Your Email Address" required>
                                </div>
                                <div class="col-md-6">
                                    <i class="fa fa-map-marker"></i>
                                    <label>Contact Address* :</label>
                                    <input type="text" name="address" class="form-control freeestimatestyle" placeholder="Enter Your Contact Address" required>
                                </div>
                            </div>
                            <div class="row form-col mb-4"> 
                                <div class="col-md-12 ">
                                    <i class="fa fa-envelope sms"></i>
                                    <label>Message :</label>
                                    <textarea name="message" rows="8" class="form-control freeestimatestyle" placeholder="Type Your Message"></textarea>
                                </div>
                                  </div>
                                <div class="col-md-6">
                                    <div class="h-captcha" data-sitekey="391cab0e-aede-4804-902c-2c5e56ac6518"></div>
                                    <input type="submit" value="Send Now" class="btn-freeestimatestyle">
                                </div>
                           
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



<style>
    .form-col .col-md-3,
    .form-col .col-md-6,
    .form-col .col-md-12{
position: relative;
    }
</style>
