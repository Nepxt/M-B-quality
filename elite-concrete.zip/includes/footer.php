<footer class="footer <?php echo ($page == 'home' ? 'home' : ''); ?>">
    <div class="container">
        <div class="row justify-content-between">
            <div class="col-md-3 mb-lg-0">
                <div class="left-footer col-md-8">
                    <div class="logo">
                        <a href="./" title=" Elite Concrete and Repairs LLC">
                            <img src="images/foot-logo.webp" alt=" Elite Concrete and Repairs LLC"
                                title=" Elite Concrete and Repairs LLC" class="img-responsive" loading="lazy">
                        </a>
                    </div>
                </div>
                <p>Elite Concrete and Repairs LLC is a trusted, locally owned company with over 15 years of experience.</p>

                <ul class="list-unstyled mt-5 d-flex align-items-center justify-content-between">
                    <li>
                        <img src="images/fema.webp" class="img-unset" alt="">
                    </li>
                    <li>
                        <a href='#' target='__bbb'><img src="images/bbb.webp" class="img-unset  " alt=""></a>

                    </li>

                </ul>
            </div>

            <div class="col-md-3 d-lg-flex justify-content-end">
                <div class="footer-list">
                    <h5>Working Hours</h5>
                    <ul class="ms-3">
                        <li>Mon: 6:00 AM - 8:00 PM</li>
                        <li>Tue: 6:00 AM - 8:00 PM</li>
                        <li>Wed: 6:00 AM - 8:00 PM</li>
                        <li>Thu: 6:00 AM - 8:00 PM</li>
                        <li>Fri: 6:00 AM - 8:00 PM</li>
                        <li>Sat: 6:00 AM - 8:00 PM</li>
                        <li>Sun: <span>By Appointment</span></li>
                    </ul>
                </div>
            </div>

            <div class="col-md-2 mb-lg-0 d-lg-flex justify-content-end">
                <div class="footer-list footer-link wow animate__animated animate__fadeInUp " data-wow-delay="0.1s"
                    data-wow-duration="1.5s" data-wow-offset="30">
                    <h5>Quick Links</h5>
                    <ul class="ms-3">
                        <li class="<?php if ($page == 'home') {
                                        echo 'active';
                                    } ?>">
                            <a href="./home" title="Home">
                                Home</a>
                        </li>
                        <li class="<?php if ($page == 'about') {
                                        echo 'active';
                                    } ?>">
                            <a href="./about" title="About">
                                About Us</a>
                        </li>
                        <li class="<?php if ($page == 'services') {
                                        echo 'active';
                                    } ?>">
                            <a href="./services" title="Services"> Services</a>
                        </li>
                        <li class="<?php if ($page == 'gallery') {
                                        echo 'active';
                                    } ?>">
                            <a href="./gallery" title="Gallery"> Gallery</a>
                        </li>
                        <li class="<?php if ($page == 'testimonials') {
                                        echo 'active';
                                    } ?>">
                            <a href="./testimonials" title="Testimonials"> Testimonials</a>
                        </li>
                        <li class="<?php if ($page == 'contact') {
                                        echo 'active';
                                    } ?>">
                            <a href="./contact" title="Contact"> Contact Us</a>
                        </li>
                    </ul>
                </div>
            </div>

            <div class="col-md-3 mb-lg-0 d-lg-flex justify-content-end">
                <div class="footer-right-wrap">
                    <div class="footer-list right-footer wow animate__animated animate__fadeInRight">
                        <h5>Contact Us</h5>
                        <ul class="list-unstyled">
                            <li class="d-flex">
                                <div class="icon-box">
                                    <iconify-icon icon="ic:baseline-phone"></iconify-icon>
                                </div>

                                <a href="tel:<?php echo $phone; ?>">
                                    <?php echo $phone; ?><br>
                                    <?php echo $phone1; ?>
                                </a>


                            </li>

                            <li class="d-flex">
                                <div class="icon-box">
                                    <iconify-icon icon="basil:gmail-solid"></iconify-icon>
                                </div>

                                <a href="mailto:<?php echo $email; ?>">
                                    <?php echo $email; ?>
                                </a>


                            </li>

                            <li class="d-flex">
                                <div class="icon-box">
                                    <iconify-icon icon="mdi:address-marker"></iconify-icon>
                                </div>

                                <a href="#">

                                    <?php echo $address; ?>
                                </a>


                            </li>

                        </ul>

                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- Go to Top Start -->
    <div id="back-top">
        <a href="#top"><span><i class="fa fa-angle-double-up" aria-hidden="true"></i></span></a>
    </div>


</footer>

</div><!-- Wrapper Close -->