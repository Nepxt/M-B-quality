<section class="services ">
    <div class="container">
        <div class="row justify-content-between align-items-center mb-5">
            <div class="col-md-4 mb-0">
                <div class="section-topic mb-0 wow animate__animated animate__fadeInDown">
                    <h5 class="section-sub">Services</h5>
                    <h2 class="section-heading">Reliable,Durable,Affordable Services You Trust</h2>

                </div>
            </div>
            <div class="col-md-5 ms-auto mb-0  mt-lg-0 mt-4 wow animate__animated animate__fadeInRight">
                <p>We provide expert roofing, concrete, siding, and gutter services with guaranteed quality, durability, and free estimates.</p>
                <a href="./services" class="btn btn-custom mt-4">Explore More</a>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6 d-flex justify-content-center">
                <div class="service-card">
                    <div class="row">
                        <div class="col-md-6 mb-0">
                            <div class="service-img"><img src="images/service1.webp" alt=""></div>
                        </div>
                        <div class="col-md-6 mb-0">
                            <div class="service-desc">
                                <h5>Shingle Roofing Services</h5>
                                <p>Expert shingle roofing solutions designed for durability, weather protection, and long-lasting curb appeal for your home.</p>
                                <hr>
                                <a href="./services" class="service-btn d-flex align-items-center">Explore More <iconify-icon class="ms-2" icon="stash:arrow-right-solid"></iconify-icon> </a>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

            <div class="col-md-6 d-flex justify-content-center">
                <div class="service-card">
                    <div class="row">
                        <div class="col-md-6 mb-0">
                            <div class="service-img"><img src="images/service2.webp" alt=""></div>
                        </div>
                        <div class="col-md-6 mb-0">
                            <div class="service-desc">
                                <h5>Fascia, Soffits & Gutters</h5>
                                <p>Complete installation and repair of fascia, soffits, and gutters to protect and ventilate your roofing system.</p>
                                <hr>
                                <a href="./services" class="service-btn d-flex align-items-center">Explore More <iconify-icon class="ms-2" icon="stash:arrow-right-solid"></iconify-icon> </a>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

            <div class="col-md-6 d-flex justify-content-center">
                <div class="service-card">
                    <div class="row">
                        <div class="col-md-6 mb-0">
                            <div class="service-img"><img src="images/service3.webp" alt=""></div>
                        </div>
                        <div class="col-md-6 mb-0">
                            <div class="service-desc h-100 d-lg-flex flex-column justify-content-between">
                                <h5>Concrete Flat Work</h5>
                                <p>High-quality flatwork including driveways, sidewalks, and patios, built to last with a smooth finish.</p>
                                <hr>
                                <a href="./services" class="service-btn d-flex align-items-center">Explore More <iconify-icon class="ms-2" icon="stash:arrow-right-solid"></iconify-icon> </a>
                            </div>
                        </div>
                    </div>
                </div>

            </div>


            <div class="col-md-6 d-flex justify-content-center">
                <div class="service-card">
                    <div class="row">
                        <div class="col-md-6 mb-0">
                            <div class="service-img"><img src="images/service4.webp" alt=""></div>
                        </div>
                        <div class="col-md-6 mb-0">
                            <div class="service-desc">
                                <h5>Siding Installation & Repairs</h5>
                                <p>Professional siding services that enhance your home’s appearance while improving insulation and protecting against the elements.</p>
                                <hr>
                                <a href="./services" class="service-btn d-flex align-items-center">Explore More <iconify-icon class="ms-2" icon="stash:arrow-right-solid"></iconify-icon> </a>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </div>
    </div>
</section>