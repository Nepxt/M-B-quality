<section class="welcome">
	<div class="container">
		<div class="row  align-items-center ">
			<div class="col-md-5 me-auto">
				<div class="welcome-img wow animate__animated animate__fadeInRight">
					<img src="images/welcome.webp" alt="">
				</div>
			</div>
			<div class="col-md-6 wow animate__animated animate__fadeInLeft">
				<div class="section-topic mb-0">
					<h5 class="section-sub">About Us</h5>
					<h2 class="section-heading">15% Discounts to all Law Enforcement, First Responders, Fire Fighters and All Military!!!!</h2>
					<p>At Elite Concrete and Repairs LLC, we take pride in delivering high-quality concrete, roofing, siding, and gutter services with a commitment to excellence and durability. With 15 years of experience, our team provides expert craftsmanship backed by a BBB A rating and FEMA certification, ensuring reliability and industry-leading standards. We guarantee all our work and offer free estimates to help you plan your project with confidence. Whether it’s shingle roofing, fascia, soffits, gutters, concrete flatwork, or siding installation and repairs, we are dedicated to exceeding your expectations.</p>
					<a href="./about" class="btn btn-custom mt-4 d-inline-flex align-items-center">Learn More</a>
				</div>
			</div>


		</div>
	</div>
</section>