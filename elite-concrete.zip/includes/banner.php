<section class="banner">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="banner-content">
                    <h5>Guaranteed Work • Free Estimates •</h5>
                    <h1>Reliable Concrete & Roofing – Quality You Trust!</h1>
                    <p>Elite Concrete and Repairs LLC offers expert concrete, roofing, siding, and gutter services with guaranteed quality, free estimates, and 15+ years of experience.</p>
                    <a href="./contact" class="btn btn-custom">Get Started</a>
                </div>
            </div>
        </div>
    </div>
</section>
<div class="banner-bottom">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <div class="banner-card">
                    <div class="card-header d-flex align-items-center ">
                        <div class="icon-box">
                            <img src="images/banner1.webp" class="img-unset" alt="">
                            <div class="house-cap">
                                <img src="images/home-cap.svg" alt="">
                            </div>
                        </div>
                        <h5>15 Years of <br>Expertise</h5>
                    </div>
                    <div class="card-desc">
                        <p>With over 15 years of experience, we deliver top-quality concrete, roofing, and siding solutions.</p>
                        
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="banner-card">
                    <div class="card-header d-flex align-items-center ">
                        <div class="icon-box">
                            <img src="images/banner2.webp" class="img-unset" alt="">
                            <div class="house-cap">
                                <img src="images/home-cap.svg" alt="">
                            </div>
                        </div>
                        <h5>BBB A-<br>Rated</h5>
                    </div>
                    <div class="card-desc">
                        <p> Our BBB A rating reflects our commitment to excellence, reliability, and customer satisfaction.</p>
                       
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="banner-card">
                    <div class="card-header d-flex align-items-center ">
                        <div class="icon-box">
                            <img src="images/banner3.webp" class="img-unset" alt="">
                            <div class="house-cap">
                                <img src="images/home-cap.svg" alt="">
                            </div>
                        </div>
                        <h5>FEMA<br> Certified</h5>
                    </div>
                    <div class="card-desc">
                        <p>As a FEMA-certified company, we ensure safe, durable, and high-quality construction services.</p>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>