<div class="content reviews">
	<div class="container">
		<div class="content-block">
			<div class="row">
				<div class="col-md-4 col-sm-6">
					<div class="reviewsblock">
						<h4>Write Your Review</h4>
					</div>
					<div class="reviewsform">
						<form class="form-horizontal" method="post" role="form" action="./testimonials-send"
							enctype="multipart/form-data">
						    <!-- Honeypot Field (Spam Prevention) -->
                            <div style="display:none;">
                              <input type="text" name="honeypot" id="honeypot" tabindex="-1" autocomplete="off" />
                            </div>
							<div class="form-group ">
								<div class="col-sm-12">
									<input type="text" name="fullName" class="form-control reviewsformstyle"
										placeholder="Name" required="">
								</div>
							</div>
							<div class="form-group ">
								<div class="col-sm-12">
									<input type="email" name="email" class="form-control reviewsformstyle"
										placeholder="Email" required="">
								</div>
							</div>
							<div class="form-group ">
								<div class="col-sm-12">
									<input type="tel" name="phone" class="form-control reviewsformstyle"
										placeholder="Phone" required="">
								</div>
							</div>
							<div class="form-group ">
								<div class="col-sm-12">
									<input type="text" name="address" class="form-control reviewsformstyle"
										placeholder="Address" required="">
								</div>
							</div>
							<div class="form-group ">
								<div class="col-sm-12">
									<textarea name="reviews" rows="8" class="form-control reviewsformstyle"
										placeholder="Your Reviews" required=""></textarea>
								</div>
							</div>
							<div class=" form-group">
								<div class="col-sm-12">
								    <div class="h-captcha" data-sitekey="391cab0e-aede-4804-902c-2c5e56ac6518"></div>
									<input type="submit" class="btn-reviewsformstyle" value="Send Review">
								</div>
							</div>
						</form>
					</div>
				</div>
				<div class="col-md-8 col-sm-6">
					<div class="reviewsblock">
						<h4>What Our Clients Say!</h4>
					</div>
					<div class="testimonials-page">
						<div class="accordion" id="accordionExample">
							<div class="accordion-item">
								<h2 class="accordion-header">
									<button class="accordion-button" type="button" data-bs-toggle="collapse"
										data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
										— Sandra H
									</button>
								</h2>
								<div id="collapseOne" class="accordion-collapse collapse show"
									data-bs-parent="#accordionExample">
									<div class="accordion-body">
									Elite Concrete and Repairs did an amazing job on our driveway and siding. The team was professional, fast, and respectful. Highly recommend them for any concrete or exterior work!
									</div>
								</div>
							</div>
							 <div class="accordion-item">
								<h2 class="accordion-header">
									<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
										data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
										- Jason T.
									</button>
								</h2>
								<div id="collapseTwo" class="accordion-collapse collapse"
									data-bs-parent="#accordionExample">
									<div class="accordion-body">
									I’m beyond happy with their roofing service! Quality work, fair pricing, and friendly service. They walked me through everything and finished on time. Will definitely use them again!
									</div>
								</div>
							</div>
						</div>
					</div>
		
				</div>

			</div>
		</div>
	</div>
</div>