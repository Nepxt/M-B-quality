<div class="content">
	<div class="container">
		<div class="content-block">
			<div class="row">
				<div class="col-sm-12">
					<h2>Our Gallery</h2>
					<div class="sectiontitleunderline"></div>
					<h3>Comming Soon....</h3>	
					<div id="gallery" style="display:none;">

						<?php for($i=1; $i<=0; $i++){ ?>
							<a href="#">
								<img alt="Gallery Image: 5 Star Iron Fabrications LLC"
								src="https://jasperusa.sfo3.cdn.digitaloceanspaces.com/5StarIronFabrications/g<?php echo $i; ?>.jpg"
								data-image="https://jasperusa.sfo3.cdn.digitaloceanspaces.com/5StarIronFabrications/g<?php echo $i; ?>.jpg"
								data-description=""
								style="display:none">
							</a>
						<?php } ?>

					</div>
				</div>
			</div>
		</div>
	</div>
</div>