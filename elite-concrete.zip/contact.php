<div class="content">
    <div class="container">
        <div class="content-block">
            <div class="row">
                <div class="col-sm-6">
                    <h2>Get In Touch With Us</h2>
                    <div class="sectiontitleunderline"></div>
                    <p class="mb-4">We are a locally owned and operated company that values honesty and integrity and
                        treats your
                        home as if it were our own. We offer a variety of services that are customizable to each
                        individual project. You will find us to be competitively priced, paying close attention to the
                        details of each and every project that we are involved with. We look forward to building lasting
                        relationships and guarantee your satisfaction!</p>
                    <h4>Ask our experts how we can help:</h4>
                    <ul>
                        <li><span>Any questions on the services we provide.</span></li>
                        <li><span>Get a personalized quote for your project.</span></li>
                        <li><span>Schedule a consultation with us.</span></li>
                        <li><span>and much more!</span></li>
                    </ul>
                    <h4>Fill out the form or call us using the phone number below:</h4>
                    <ul class=" br-none">
                        <li><span><strong>Phone: </strong>
                                <?php echo $phone; ?>
                        </li>
                        <li><span><strong>Email: </strong>
                                <?php echo $email; ?>
                        </li>
                        <li><span><strong>Address: </strong>
                                <?php echo $address; ?>
                        </li>
                    </ul>
                </div>
                <div class="col-sm-6">
                    <h2>Contact Us</h2>
                    <div class="sectiontitleunderline"></div>
                    <p>Please note all fields are required.</p>
                    <div class="form_section">
                        <form class="form-horizontal" method="post" role="form" action="./contact-send"
                            enctype="multipart/form-data" id="form">
                            <div class="form-group">
                                <div class="row">
                                    <!-- Honeypot Field (Spam Prevention) -->
                                    <div style="display:none;">
                                      <input type="text" name="honeypot" id="honeypot" tabindex="-1" autocomplete="off" />
                                    </div>
                                    <div class="col-sm-6 d-flex mt-2 position-relative">
                                        <i class="fa fa-user"></i>
                                        <input type="text" name="fullName" class="form-control formstyle"
                                            placeholder="Full Name" required />
                                    </div>
                                    <div class="col-sm-6 d-flex mt-2 position-relative">
                                        <i class="fa fa-paper-plane"></i>
                                        <input type="email" name="email" class="form-control formstyle"
                                            placeholder="Email" required
                                            pattern="^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$" />
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-sm-6 d-flex mt-2 position-relative">
                                        <i class="fa fa-phone"></i>
                                        <input type="tel" name="phone" class="form-control formstyle"
                                            placeholder="Phone" required
                                            pattern="^([0-9]{3})?([ ]{1})?([0-9]{3})?([ ]{1})?([0-9]{4})$"
                                            minlength="10" maxlength="12" />
                                    </div>
                                    <div class="col-sm-6 d-flex mt-2 position-relative">
                                        <i class="fa fa-map-marker"></i>
                                        <input type="text" name="address" class="form-control formstyle"
                                            placeholder="Address" required />
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-sm-12 mt-2  position-relative">
                                        <i class="fa fa-envelope sms"></i>
                                        <textarea name="message" class="form-control formstyle form-msg" rows="8"
                                            placeholder="Message" required></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="h-captcha" data-sitekey="391cab0e-aede-4804-902c-2c5e56ac6518"></div>
                                        <button type="submit" name="btnSubmit" class="btn-formstyle">Submit</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-sm-12">
                    <div class="contact-page-location-map">
                        <h2>Location Map</h2>
                        <div class="sectiontitleunderline"></div>
                        <div class="googlemap">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d87269.04049768746!2d-96.80634103205206!3d46.87994967777346!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x52c8c8ca1e446d3b%3A0x2328e846d803c816!2sMoorhead%2C%20MN%2C%20USA!5e0!3m2!1sen!2snp!4v1744238479966!5m2!1sen!2snp" width="100%" height="100%" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>





<style>
    .form_section .fa {
        position: absolute;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100%;
        width: 50px;
        text-align: center;
        color: #fff;
        background-color: #0000ff ;
        font-size: 18px;
    }

    .formstyle {
        padding-left: 60px;
        border-color: #ddd;
        border-radius: 0;
        background-color: #fff;
        color: #000;
    }

    .form-msg {
        height: unset;
    }

    .text-dark li {
        color: #666 !important;
    }
</style>